# Implementation status

| Area | Status | Notes |
|---|---|---|
| Bevy app skeleton | Implemented in source | Rust compile not verified here |
| Three selectable maps | Implemented in source | Distinct layout and floor materials |
| PBR materials and normal maps | Implemented in source | No SSR/reflection probes |
| Directional shadows | Implemented in source | Quality profiles toggle shadow settings |
| Explorer models | Included | 3 stylized skinned GLBs |
| Sentinel models | Included | 3 stylized skinned GLBs |
| Skeletal animation clips | Included | Idle, Walk, Scan, Shutdown |
| Main menu / pause / settings | Implemented in source | Bevy UI |
| Workshop and upgrades | Implemented in source | Scanner, suit lining, battery |
| Inventory | Implemented in source | Resource and upgrade summary |
| Character editor | Partial | Three suit colourways only |
| Quests and story | Partial | Three regional briefs, common objective structure |
| Touch controls | Implemented in source | Requires physical-device validation |
| Save/load | Implemented in source | Relative path; Android path still needs adaptation |
| FPS/frame-time/entity overlay | Implemented in source | No CPU/GPU temperature/load sensors |
| Offline asset validation | Passed | 661 checks |
| `cargo check` | Not run | Rust toolchain absent from build environment |
| Android APK | Not built | Android packaging not included |
