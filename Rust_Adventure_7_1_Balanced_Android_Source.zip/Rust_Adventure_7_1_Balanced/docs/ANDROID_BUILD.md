# Android APK build setup

This package changes Bevy 0.15.3 to its legacy `NativeActivity` backend so it can be packaged by `cargo-apk`. Bevy 0.15 defaults to `GameActivity`; `cargo-apk` does not package GameActivity. The official Bevy 0.15.3 mobile example uses `android-native-activity`, `android_shared_stdcxx`, a library target and `#[bevy_main]`.

The workflow template is `android-apk-workflow.yml`. To use it in GitHub, place its contents at `.github/workflows/android-apk.yml` **after** extracting this source archive into the repository root. It builds only `aarch64-linux-android` (64-bit ARM), appropriate for most current Android phones.

This is a build configuration, not a verified APK. GitHub Actions must run successfully; then download the artifact named `Rust-Adventure-7.1-Android-APK`. Test the APK on the target phone.
