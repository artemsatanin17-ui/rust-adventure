#!/usr/bin/env python3
"""Generate original low-poly, skinned glTF 2.0 character assets for RUST ADVENTURE.

The models are deliberately stylized sci-fi explorers/sentinels, not realistic people.
Each GLB includes Idle, Walk, Scan and Shutdown skeletal animation clips.
"""
from __future__ import annotations
import json, math, struct
from pathlib import Path
import numpy as np
import trimesh

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "assets" / "models"
OUT.mkdir(parents=True, exist_ok=True)

# Joint palette: root, pelvis, spine, head, left arm, right arm, left leg, right leg.
BONE = {"root":0, "pelvis":1, "spine":2, "head":3, "left_arm":4, "right_arm":5, "left_leg":6, "right_leg":7}
PARENT = {0:None, 1:0, 2:1, 3:2, 4:2, 5:2, 6:1, 7:1}
LOCAL = {
    0:(0.0,0.0,0.0), 1:(0.0,0.92,0.0), 2:(0.0,0.43,0.0),
    3:(0.0,0.48,0.0), 4:(-0.34,0.24,0.0), 5:(0.34,0.24,0.0),
    6:(-0.16,-0.48,0.0), 7:(0.16,-0.48,0.0),
}

def box(center, extents, color, bone, rot=None):
    m = trimesh.creation.box(extents=extents)
    if rot is not None:
        m.apply_transform(trimesh.transformations.rotation_matrix(rot[0], rot[1]))
    m.apply_translation(center)
    return m, color, bone

def sphere(center, radius, color, bone, subdivisions=2):
    m = trimesh.creation.icosphere(subdivisions=subdivisions, radius=radius)
    m.apply_translation(center)
    return m, color, bone

def cylinder(center, radius, height, color, bone, axis=(0,1,0)):
    m = trimesh.creation.cylinder(radius=radius, height=height, sections=10)
    m.apply_transform(trimesh.geometry.align_vectors([0,0,1], axis))
    m.apply_translation(center)
    return m, color, bone

def build_parts(kind: str):
    if kind == "explorer":
        main=(0.12,0.45,0.62,1.0); light=(0.56,0.78,0.82,1.0); dark=(0.035,0.09,0.14,1.0); glow=(0.08,0.9,0.8,1.0); accent=(0.98,0.55,0.18,1.0)
    elif kind == "explorer_moss":
        main=(0.20,0.42,0.29,1.0); light=(0.61,0.72,0.48,1.0); dark=(0.045,0.12,0.08,1.0); glow=(0.48,0.92,0.40,1.0); accent=(0.88,0.65,0.25,1.0)
    elif kind == "explorer_ember":
        main=(0.52,0.22,0.15,1.0); light=(0.80,0.50,0.32,1.0); dark=(0.16,0.055,0.04,1.0); glow=(1.0,0.45,0.12,1.0); accent=(0.95,0.78,0.46,1.0)
    elif kind == "sentinel":
        main=(0.20,0.30,0.37,1.0); light=(0.35,0.47,0.52,1.0); dark=(0.045,0.075,0.10,1.0); glow=(1.0,0.30,0.08,1.0); accent=(0.72,0.82,0.88,1.0)
    elif kind == "sentinel_ice":
        main=(0.25,0.45,0.60,1.0); light=(0.63,0.83,0.92,1.0); dark=(0.07,0.16,0.23,1.0); glow=(0.1,0.78,1.0,1.0); accent=(0.82,0.92,0.98,1.0)
    else:
        main=(0.35,0.27,0.18,1.0); light=(0.73,0.55,0.31,1.0); dark=(0.12,0.08,0.055,1.0); glow=(1.0,0.58,0.12,1.0); accent=(0.90,0.75,0.50,1.0)
    parts=[]
    # Pelvis and torso armor.
    parts += [box((0,0.91,0),(0.42,0.32,0.27),dark,BONE['pelvis'])]
    parts += [box((0,1.39,0),(0.52,0.61,0.31),main,BONE['spine'])]
    parts += [box((0,1.48,-0.17),(0.46,0.32,0.12),light,BONE['spine'])]
    parts += [box((0,1.16,-0.18),(0.36,0.12,0.10),accent,BONE['pelvis'])]
    # Neck and head.
    parts += [cylinder((0,1.82,0),0.09,0.14,dark,BONE['head'])]
    parts += [sphere((0,2.02,0),(0.23),light,BONE['head'],2)]
    parts += [box((0,2.03,-0.19),(0.29,0.105,0.075),glow,BONE['head'])]
    parts += [box((0,2.23,0),(0.12,0.06,0.12),accent,BONE['head'])]
    # Shoulder blocks, arms and gloves.
    for sign, joint in [(-1,BONE['left_arm']),(1,BONE['right_arm'])]:
        parts += [sphere((sign*0.39,1.61,0),0.16,accent,joint,1)]
        parts += [box((sign*0.48,1.39,0),(0.19,0.43,0.22),main,joint)]
        parts += [box((sign*0.52,1.12,-0.02),(0.18,0.20,0.20),dark,joint)]
        parts += [box((sign*0.52,1.02,-0.055),(0.17,0.10,0.16),glow,joint)]
    # Legs and boots.
    for sign,joint in [(-1,BONE['left_leg']),(1,BONE['right_leg'])]:
        parts += [box((sign*0.16,0.66,0),(0.20,0.42,0.25),main,joint)]
        parts += [box((sign*0.16,0.30,-0.055),(0.22,0.28,0.31),dark,joint)]
        parts += [box((sign*0.16,0.17,-0.12),(0.24,0.10,0.38),accent,joint)]
    # Backpack and sensor mast create a distinct silhouette.
    parts += [box((0,1.43,0.22),(0.34,0.48,0.18),dark,BONE['spine'])]
    parts += [box((0,1.54,0.325),(0.24,0.20,0.055),glow,BONE['spine'])]
    if kind != "explorer":
        parts += [cylinder((0,2.34,0),0.045,0.22,glow,BONE['head'])]
        parts += [sphere((0,2.47,0),0.075,glow,BONE['head'],1)]
    if kind == "sentinel_heavy":
        parts += [box((0,1.48,-0.24),(0.66,0.38,0.16),accent,BONE['spine'])]
        parts += [box((0,0.78,0.18),(0.64,0.19,0.17),light,BONE['pelvis'])]
    return parts

def qx(deg):
    r=math.radians(deg)/2
    return [math.sin(r),0.0,0.0,math.cos(r)]
def qz(deg):
    r=math.radians(deg)/2
    return [0.0,0.0,math.sin(r),math.cos(r)]

def make_glb(kind: str, path: Path):
    vertices=[]; normals=[]; colors=[]; joints=[]; weights=[]; indices=[]
    parts=build_parts(kind)
    for mesh,color,bone in parts:
        v=np.asarray(mesh.vertices,dtype=np.float32)
        n=np.asarray(mesh.vertex_normals,dtype=np.float32)
        base=len(vertices)
        vertices.extend(v.tolist()); normals.extend(n.tolist())
        colors.extend([list(color)]*len(v))
        joints.extend([[bone,0,0,0]]*len(v)); weights.extend([[1.0,0.0,0.0,0.0]]*len(v))
        indices.extend((np.asarray(mesh.faces,dtype=np.uint32)+base).ravel().tolist())
    vertices=np.asarray(vertices,dtype=np.float32); normals=np.asarray(normals,dtype=np.float32)
    colors=np.asarray(colors,dtype=np.float32); joints=np.asarray(joints,dtype=np.uint8)
    weights=np.asarray(weights,dtype=np.float32); indices=np.asarray(indices,dtype=np.uint32)

    # Inverse bind matrices for a simple parented humanoid rig.
    world={}
    for j in range(8):
        p=PARENT[j]
        local=np.array(LOCAL[j],dtype=np.float32)
        world[j]=local if p is None else world[p]+local
    ibm=[]
    for j in range(8):
        mat=np.eye(4,dtype=np.float32); mat[:3,3]=-world[j]
        ibm.extend(mat.reshape(-1,order='F').tolist())
    ibm=np.asarray(ibm,dtype=np.float32).reshape((8,16))

    blob=bytearray(); views=[]; accessors=[]
    def add_view(data: bytes, target=None):
        while len(blob)%4: blob.append(0)
        off=len(blob); blob.extend(data)
        row={"buffer":0,"byteOffset":off,"byteLength":len(data)}
        if target is not None: row["target"]=target
        views.append(row); return len(views)-1
    def add_accessor(arr, typ, component, target=None, normalized=False, include_bounds=False):
        arr=np.ascontiguousarray(arr)
        view=add_view(arr.tobytes(),target)
        count=len(arr)
        a={"bufferView":view,"componentType":component,"count":count,"type":typ}
        if normalized: a["normalized"]=True
        if include_bounds and arr.ndim==2:
            a["min"]=arr.min(axis=0).astype(float).tolist(); a["max"]=arr.max(axis=0).astype(float).tolist()
        accessors.append(a); return len(accessors)-1

    pos_a=add_accessor(vertices,"VEC3",5126,34962,include_bounds=True)
    norm_a=add_accessor(normals,"VEC3",5126,34962)
    color_a=add_accessor(colors,"VEC4",5126,34962)
    joint_a=add_accessor(joints,"VEC4",5121,34962)
    weight_a=add_accessor(weights,"VEC4",5126,34962)
    index_a=add_accessor(indices.reshape((-1,1)),"SCALAR",5125,34963)
    ibm_a=add_accessor(ibm,"MAT4",5126)

    animations=[]
    def add_animation(name, keys, channels):
        samplers=[]; ch=[]
        times=np.asarray(keys,dtype=np.float32).reshape((-1,1))
        ti=add_accessor(times,"SCALAR",5126)
        for node,path_name,values,typ in channels:
            arr=np.asarray(values,dtype=np.float32)
            oi=add_accessor(arr,typ,5126)
            si=len(samplers); samplers.append({"input":ti,"output":oi,"interpolation":"LINEAR"})
            ch.append({"sampler":si,"target":{"node":node,"path":path_name}})
        animations.append({"name":name,"samplers":samplers,"channels":ch})

    add_animation("Idle",[0,1.0,2.0], [
        (1,"translation",[[0,.92,0],[0,.95,0],[0,.92,0]],"VEC3"),
        (4,"rotation",[qx(-4),qx(2),qx(-4)],"VEC4"),
        (5,"rotation",[qx(4),qx(-2),qx(4)],"VEC4"),
    ])
    add_animation("Walk",[0,.25,.5,.75,1.0], [
        (1,"translation",[[0,.92,0],[0,.99,0],[0,.92,0],[0,.99,0],[0,.92,0]],"VEC3"),
        (4,"rotation",[qx(-18),qx(18),qx(-18),qx(18),qx(-18)],"VEC4"),
        (5,"rotation",[qx(18),qx(-18),qx(18),qx(-18),qx(18)],"VEC4"),
        (6,"rotation",[qx(24),qx(0),qx(-24),qx(0),qx(24)],"VEC4"),
        (7,"rotation",[qx(-24),qx(0),qx(24),qx(0),qx(-24)],"VEC4"),
    ])
    add_animation("Scan",[0,.35,.7,1.05], [
        (2,"rotation",[qz(0),qz(-4),qz(0),qz(0)],"VEC4"),
        (5,"rotation",[qx(-8),qx(-48),qx(-48),qx(-8)],"VEC4"),
        (4,"rotation",[qx(5),qx(3),qx(5),qx(5)],"VEC4"),
    ])
    add_animation("Shutdown",[0,.4,.8,1.2], [
        (1,"translation",[[0,.92,0],[0,.82,0],[0,.42,0],[0,.35,0]],"VEC3"),
        (2,"rotation",[qz(0),qz(8),qz(28),qz(35)],"VEC4"),
        (4,"rotation",[qx(0),qx(-20),qx(-70),qx(-80)],"VEC4"),
        (5,"rotation",[qx(0),qx(20),qx(70),qx(80)],"VEC4"),
    ])

    gltf={
        "asset":{"version":"2.0","generator":"RUST ADVENTURE original skinned asset builder"},
        "scene":0,
        "scenes":[{"name":"CharacterScene","nodes":[0,8]}],
        "nodes":[
            {"name":"Root","children":[1]},
            {"name":"Pelvis","translation":list(LOCAL[1]),"children":[2,6,7]},
            {"name":"Spine","translation":list(LOCAL[2]),"children":[3,4,5]},
            {"name":"Head","translation":list(LOCAL[3])},
            {"name":"LeftArm","translation":list(LOCAL[4])},
            {"name":"RightArm","translation":list(LOCAL[5])},
            {"name":"LeftLeg","translation":list(LOCAL[6])},
            {"name":"RightLeg","translation":list(LOCAL[7])},
            {"name":"SkinnedMesh","mesh":0,"skin":0},
        ],
        "skins":[{"name":"ExplorerRig","inverseBindMatrices":ibm_a,"skeleton":0,"joints":[0,1,2,3,4,5,6,7]}],
        "meshes":[{"name":kind,"primitives":[{"attributes":{"POSITION":pos_a,"NORMAL":norm_a,"COLOR_0":color_a,"JOINTS_0":joint_a,"WEIGHTS_0":weight_a},"indices":index_a,"material":0,"mode":4}]}],
        "materials":[{"name":"PaintedPolymer","pbrMetallicRoughness":{"baseColorFactor":[1,1,1,1],"metallicFactor":0.28,"roughnessFactor":0.62},"doubleSided":True}],
        "animations":animations,
        "buffers":[{"byteLength":len(blob)}],"bufferViews":views,"accessors":accessors,
    }
    js=json.dumps(gltf,separators=(',',':')).encode('utf-8')
    while len(js)%4: js+=b' '
    while len(blob)%4: blob.append(0)
    total=12+8+len(js)+8+len(blob)
    out=bytearray(struct.pack('<4sII',b'glTF',2,total))
    out.extend(struct.pack('<I4s',len(js),b'JSON')); out.extend(js)
    out.extend(struct.pack('<I4s',len(blob),b'BIN\x00')); out.extend(blob)
    path.write_bytes(out)
    print(f"{path.name}: {len(out):,} bytes | vertices={len(vertices)} | animations={len(animations)}")

for name in ["explorer","explorer_moss","explorer_ember","sentinel","sentinel_ice","sentinel_heavy"]:
    make_glb(name, OUT / f"{name}.glb")
