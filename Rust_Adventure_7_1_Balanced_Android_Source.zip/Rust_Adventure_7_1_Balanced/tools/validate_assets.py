#!/usr/bin/env python3
"""Offline structural checks for RUST ADVENTURE assets and source references.

This does not replace `cargo check`; it validates bundled data files and checks
that asset paths referenced by the Rust source actually exist.
"""
from __future__ import annotations
import json
import re
import struct
import wave
from pathlib import Path
from PIL import Image

ROOT = Path(__file__).resolve().parents[1]
SRC = ROOT / "src" / "main.rs"
ASSETS = ROOT / "assets"
errors: list[str] = []
checks = 0

def check(condition: bool, message: str) -> None:
    global checks
    checks += 1
    if not condition:
        errors.append(message)

source = SRC.read_text(encoding="utf-8")
# Check every literal AssetServer path, e.g. `models/..`, `audio/..`.
asset_paths = sorted(set(re.findall(r'"((?:models|textures|audio)/[^"\\]+)"', source)))
for rel in asset_paths:
    check((ASSETS / rel).is_file(), f"Rust references missing asset: {rel}")

# Check all known asset directories, and parse each binary format.
model_files = sorted((ASSETS / "models").glob("*.glb"))
check(len(model_files) >= 6, f"Expected 6 character GLBs, found {len(model_files)}")
for path in model_files:
    raw = path.read_bytes()
    ok_header = len(raw) >= 20 and raw[:4] == b"glTF"
    check(ok_header, f"Invalid GLB header: {path.name}")
    if not ok_header:
        continue
    magic, version, total = struct.unpack_from("<4sII", raw, 0)
    check(version == 2, f"GLB is not glTF 2.0: {path.name}")
    check(total == len(raw), f"GLB total length mismatch: {path.name}")
    json_len, json_type = struct.unpack_from("<I4s", raw, 12)
    check(json_type == b"JSON", f"Missing JSON chunk: {path.name}")
    json_start = 20
    json_end = json_start + json_len
    check(json_end + 8 <= len(raw), f"JSON chunk out of bounds: {path.name}")
    try:
        doc = json.loads(raw[json_start:json_end].decode("utf-8").rstrip(" \t\r\n\0"))
    except Exception as exc:
        errors.append(f"Could not parse GLB JSON {path.name}: {exc}")
        continue
    check(doc.get("asset", {}).get("version") == "2.0", f"glTF asset version mismatch: {path.name}")
    bin_header = json_end
    bin_len, bin_type = struct.unpack_from("<I4s", raw, bin_header)
    check(bin_type == b"BIN\0", f"Missing BIN chunk: {path.name}")
    bin_start = bin_header + 8
    bin_end = bin_start + bin_len
    check(bin_end <= len(raw), f"BIN chunk out of bounds: {path.name}")
    binary = raw[bin_start:bin_end]
    buffers = doc.get("buffers", [])
    check(bool(buffers), f"No glTF buffers: {path.name}")
    if buffers:
        check(buffers[0].get("byteLength", 0) <= len(binary), f"Buffer is longer than BIN chunk: {path.name}")
    views = doc.get("bufferViews", [])
    accessors = doc.get("accessors", [])
    for i, view in enumerate(views):
        off = view.get("byteOffset", 0)
        length = view.get("byteLength", 0)
        check(view.get("buffer", 0) == 0 and off + length <= len(binary), f"bufferView {i} out of bounds: {path.name}")
    for i, accessor in enumerate(accessors):
        check(0 <= accessor.get("bufferView", -1) < len(views), f"accessor {i} bad bufferView: {path.name}")
    nodes = doc.get("nodes", [])
    skins = doc.get("skins", [])
    anims = doc.get("animations", [])
    meshes = doc.get("meshes", [])
    check(bool(meshes), f"No mesh in GLB: {path.name}")
    check(bool(skins) and len(skins[0].get("joints", [])) >= 6, f"No useful skeletal rig in GLB: {path.name}")
    check(len(anims) >= 4, f"Expected four animation clips in GLB: {path.name}")
    for skin in skins:
        check(all(0 <= joint < len(nodes) for joint in skin.get("joints", [])), f"Skin has invalid joint node: {path.name}")
        ibm = skin.get("inverseBindMatrices", -1)
        check(0 <= ibm < len(accessors), f"Skin has invalid inverse bind matrices: {path.name}")
    for anim in anims:
        check(bool(anim.get("channels")) and bool(anim.get("samplers")), f"Empty animation clip {anim.get('name')} in {path.name}")
        for channel in anim.get("channels", []):
            node = channel.get("target", {}).get("node", -1)
            check(0 <= node < len(nodes), f"Animation targets missing node in {path.name}")
            sampler = channel.get("sampler", -1)
            check(0 <= sampler < len(anim.get("samplers", [])), f"Animation has invalid sampler in {path.name}")
    print(f"GLB OK  {path.name:24} nodes={len(nodes):2} joints={len(skins[0]['joints']) if skins else 0} clips={len(anims)}")

texture_files = sorted((ASSETS / "textures").glob("*.png"))
check(len(texture_files) >= 6, f"Expected multiple texture maps, found {len(texture_files)}")
for path in texture_files:
    try:
        with Image.open(path) as im:
            im.verify()
        with Image.open(path) as im:
            check(im.width >= 128 and im.height >= 128, f"Texture too small: {path.name}")
        print(f"PNG OK  {path.name:24}")
    except Exception as exc:
        errors.append(f"Invalid PNG {path.name}: {exc}")

audio_files = sorted((ASSETS / "audio").glob("*.wav"))
check(len(audio_files) >= 4, f"Expected 4 WAV cues, found {len(audio_files)}")
for path in audio_files:
    try:
        with wave.open(str(path), "rb") as f:
            check(f.getnchannels() in (1, 2), f"Unsupported WAV channel count: {path.name}")
            check(f.getsampwidth() in (1, 2, 3, 4), f"Unsupported WAV sample width: {path.name}")
            check(f.getframerate() >= 8000, f"WAV sample rate too low: {path.name}")
            check(f.getnframes() > 0, f"Empty WAV file: {path.name}")
        print(f"WAV OK  {path.name:24}")
    except Exception as exc:
        errors.append(f"Invalid WAV {path.name}: {exc}")

# Confirm the app's declared Bevy version and major system function references.
cargo = (ROOT / "Cargo.toml").read_text(encoding="utf-8")
check('version = "0.15.3"' in cargo, "Expected Bevy 0.15.3 in Cargo.toml")
functions = set(re.findall(r"(?m)^fn\s+([A-Za-z_][A-Za-z0-9_]*)\s*\(", source))
for required in [
    "load_progress", "setup_world", "setup_ui", "setup_animation_graph",
    "handle_keyboard_actions", "handle_ui_actions", "style_ui_buttons",
    "collect_touch_controls", "rebuild_world", "player_movement", "camera_look",
    "handle_interaction", "collect_pickups", "sentinel_ai", "update_mission",
    "update_performance", "sync_ui_pages", "update_ui_text",
    "update_preview_visibility", "save_progress", "bind_character_animations",
    "update_scene_animations",
]:
    check(required in functions, f"Missing required system function: {required}")
check("spawn_wave_system" not in source and "cleanup_dead_enemies" not in source, "Old undefined 7.0 systems still referenced")

print(f"\nChecks run: {checks}")
if errors:
    print(f"FAILED: {len(errors)} issue(s)")
    for error in errors:
        print(f" - {error}")
    raise SystemExit(1)
print("All offline asset/source-reference checks passed.")
