#!/usr/bin/env python3
"""Generate lightweight original textures and interface audio for RUST ADVENTURE 7.1."""
from pathlib import Path
import math, wave
import numpy as np
from PIL import Image, ImageDraw, ImageFilter

ROOT=Path(__file__).resolve().parents[1]
TEX=ROOT/'assets'/'textures'
AUD=ROOT/'assets'/'audio'
TEX.mkdir(parents=True,exist_ok=True); AUD.mkdir(parents=True,exist_ok=True)
rng=np.random.default_rng(711)
# A fine brushed alloy texture with an enamel panel, vents and screw heads.
w=h=512
noise=rng.normal(0,7,(h,w,1))
y=np.linspace(0,1,h)[:,None,None]
base=np.zeros((h,w,3),dtype=np.float32)
base[:]=[33,58,68]
base += noise
base += (np.sin(np.linspace(0,math.pi*16,h))[:,None,None]*4)
base=np.clip(base,0,255).astype('uint8')
im=Image.fromarray(base,'RGB')
d=ImageDraw.Draw(im)
d.rounded_rectangle((42,40,470,470),radius=26,outline=(100,160,166),width=5,fill=(38,69,80))
d.rounded_rectangle((85,95,430,305),radius=16,fill=(17,37,48),outline=(75,130,140),width=4)
d.rectangle((115,125,402,148),fill=(53,94,104))
d.rounded_rectangle((145,180,370,260),radius=12,fill=(19,91,93),outline=(55,192,176),width=5)
for x in range(125,400,28):
    d.line((x,335,x+10,382),fill=(95,126,132),width=5)
for x,y0 in [(66,65),(446,65),(66,444),(446,444)]:
    d.ellipse((x-9,y0-9,x+9,y0+9),fill=(145,167,168),outline=(30,48,55),width=3)
im=im.filter(ImageFilter.GaussianBlur(0.35))
im.save(TEX/'scanner_basecolor.png')

# Grayscale normal-style noise for scanner prop. It's decorative and not used as a true tangent-space normal map.
noise=rng.normal(128,9,(h,w)).clip(90,166).astype('uint8')
Image.fromarray(noise,'L').save(TEX/'scanner_surface.png')

# Original short electronic UI sounds. They are intentionally soft, non-alarmist interface cues.
def write_tone(name, freqs, duration=0.25, volume=0.18, sweep=False):
    sr=22050; n=int(sr*duration); t=np.arange(n)/sr
    if sweep:
        phase=2*np.pi*(freqs[0]*t + (freqs[1]-freqs[0])*t*t/(2*duration))
        sig=np.sin(phase)
    else:
        sig=sum(np.sin(2*np.pi*f*t)/len(freqs) for f in freqs)
    env=np.minimum(1,t*45)*np.minimum(1,(duration-t)*16)
    sig=(sig*env*volume*32767).astype('<i2')
    with wave.open(str(AUD/name),'wb') as f:
        f.setnchannels(1); f.setsampwidth(2); f.setframerate(sr); f.writeframes(sig.tobytes())

write_tone('beacon.wav',[520,780],0.42,0.19,True)
write_tone('collect.wav',[920,1250],0.12,0.13,True)
write_tone('alert.wav',[260,190],0.32,0.11,True)
write_tone('ui_click.wav',[640],0.06,0.08,False)
print('Generated scanner textures and interface WAV audio.')
