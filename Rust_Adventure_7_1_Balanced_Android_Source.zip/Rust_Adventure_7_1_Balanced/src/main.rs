fn main() {
    rust_adventure_7::run_game();
}
