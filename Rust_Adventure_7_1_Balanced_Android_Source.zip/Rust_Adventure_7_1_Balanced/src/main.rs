use bevy::{
    hierarchy::{ChildBuilder, DespawnRecursiveExt},
    animation::{AnimationGraph, AnimationGraphHandle, AnimationPlayer, AnimationTransitions},
    input::mouse::MouseMotion,
    prelude::*,
};
use serde::{Deserialize, Serialize};
use std::{fs, path::Path, time::Duration};

const GAME_TITLE: &str = "RUST / ADVENTURE";
const PLAYER_SPEED: f32 = 6.0;
const SPRINT_MULTIPLIER: f32 = 1.55;
const MAX_CHARGE: f32 = 100.0;
const BEACONS_PER_MISSION: u8 = 3;
const FRAGMENTS_PER_MISSION: u8 = 4;

fn main() {
    App::new()
        .insert_resource(ClearColor(Color::srgb(0.018, 0.032, 0.052)))
        .init_resource::<GameState>()
        .init_resource::<MapConfig>()
        .init_resource::<TouchControls>()
        .init_resource::<InteractionRequest>()
        .init_resource::<PerformanceMonitor>()
        .init_resource::<SaveData>()
        .add_plugins(DefaultPlugins.set(WindowPlugin {
            primary_window: Some(Window {
                title: "RUST ADVENTURE 7.1 // BALANCED".into(),
                resolution: (1280.0, 720.0).into(),
                resizable: true,
                ..default()
            }),
            ..default()
        }))
        .add_systems(Startup, (load_progress, setup_world, setup_ui, setup_animation_graph).chain())
        .add_systems(
            Update,
            (
                handle_keyboard_actions,
                handle_ui_actions,
                style_ui_buttons,
                collect_touch_controls,
                rebuild_world,
                player_movement,
                camera_look,
                handle_interaction,
                collect_pickups,
                sentinel_ai,
                update_mission,
                update_performance,
                sync_ui_pages,
                update_ui_text,
                update_preview_visibility,
                save_progress,
                bind_character_animations,
                update_scene_animations,
            )
                .chain(),
        )
        .run();
}

// -----------------------------------------------------------------------------
// GAME STATE AND DATA
// -----------------------------------------------------------------------------

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
enum Screen {
    MainMenu,
    Playing,
    MapSelect,
    Workshop,
    Inventory,
    Character,
    Settings,
    Pause,
    MissionComplete,
}

#[derive(Clone, Copy, Debug, PartialEq, Eq, Serialize, Deserialize)]
enum MapKind {
    RustDunes,
    NeonDistrict,
    FrostRelay,
}

impl Default for MapKind {
    fn default() -> Self { Self::RustDunes }
}

impl MapKind {
    fn title(self) -> &'static str {
        match self {
            Self::RustDunes => "01 // RUST DUNES",
            Self::NeonDistrict => "02 // NEON DISTRICT",
            Self::FrostRelay => "03 // FROST RELAY",
        }
    }
    fn mission(self) -> &'static str {
        match self {
            Self::RustDunes => "Restore the old desert relay network.",
            Self::NeonDistrict => "Recover the city archive signal.",
            Self::FrostRelay => "Bring the frozen research array back online.",
        }
    }
    fn texture(self) -> &'static str {
        match self {
            Self::RustDunes => "textures/sand_basecolor.png",
            Self::NeonDistrict => "textures/concrete_basecolor.png",
            Self::FrostRelay => "textures/ice_basecolor.png",
        }
    }
    fn normal_texture(self) -> &'static str {
        match self {
            Self::RustDunes => "textures/sand_normal.png",
            Self::NeonDistrict => "textures/concrete_normal.png",
            Self::FrostRelay => "textures/concrete_normal.png",
        }
    }
}

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
enum QualityPreset { Performance, Balanced, High }

impl Default for QualityPreset {
    fn default() -> Self { Self::Balanced }
}

#[derive(Resource)]
struct GameState {
    screen: Screen,
    quality: QualityPreset,
    message: String,
    beacons_found: u8,
    fragments_found: u8,
    mission_stage: u8,
    charge: f32,
    alert: f32,
}

impl Default for GameState {
    fn default() -> Self {
        Self {
            screen: Screen::MainMenu,
            quality: QualityPreset::Balanced,
            message: "A signal is waiting beyond the dunes.".into(),
            beacons_found: 0,
            fragments_found: 0,
            mission_stage: 0,
            charge: MAX_CHARGE,
            alert: 0.0,
        }
    }
}

#[derive(Resource)]
struct MapConfig {
    selected: MapKind,
    rebuild: bool,
}
impl Default for MapConfig {
    fn default() -> Self { Self { selected: MapKind::RustDunes, rebuild: true } }
}

#[derive(Resource, Serialize, Deserialize, Clone, PartialEq)]
#[serde(default)]
struct SaveData {
    scrap: u32,
    data_fragments: u32,
    total_beacons: u32,
    completed_missions: u32,
    scanner_level: u8,
    suit_level: u8,
    battery_level: u8,
    suit_choice: u8,
    last_map: MapKind,
}
impl Default for SaveData {
    fn default() -> Self {
        Self {
            scrap: 80,
            data_fragments: 0,
            total_beacons: 0,
            completed_missions: 0,
            scanner_level: 1,
            suit_level: 1,
            battery_level: 1,
            suit_choice: 0,
            last_map: MapKind::RustDunes,
        }
    }
}

#[derive(Resource, Default)]
struct TouchControls {
    forward: bool,
    backward: bool,
    left: bool,
    right: bool,
    look_left: bool,
    look_right: bool,
    sprint: bool,
}

#[derive(Resource, Default)]
struct InteractionRequest { requested: bool }

#[derive(Resource)]
struct PerformanceMonitor {
    fps: f32,
    frame_ms: f32,
    update_timer: Timer,
    entity_count: usize,
}
impl Default for PerformanceMonitor {
    fn default() -> Self {
        Self {
            fps: 0.0,
            frame_ms: 0.0,
            update_timer: Timer::from_seconds(0.35, TimerMode::Repeating),
            entity_count: 0,
        }
    }
}

#[derive(Resource)]
struct AnimationBank {
    graph: Handle<AnimationGraph>,
    idle: AnimationNodeIndex,
    walk: AnimationNodeIndex,
    scan: AnimationNodeIndex,
    shutdown: AnimationNodeIndex,
}

#[derive(Component)] struct CurrentClip(AnimationNodeIndex);
#[derive(Component)] struct PlayerRoot;
#[derive(Component)] struct PlayerCamera;
#[derive(Component)] struct LevelObject;
#[derive(Component)] struct PreviewAvatar(u8);
#[derive(Component)] struct MapBlocker { half: Vec2 }
#[derive(Component)] struct Beacon { index: u8, activated: bool }
#[derive(Component)] struct DataFragment;
#[derive(Component)] struct Sentinel {
    speed: f32,
    detect_radius: f32,
    patrol_center: Vec3,
    phase: f32,
}
#[derive(Component)] struct UiRoot;
#[derive(Component)] struct UiPage(Screen);
#[derive(Component)] struct DynamicLabel(LabelKind);
#[derive(Component, Clone, Copy)] enum LabelKind { MainStats, Hud, Quest, Message, Performance, Inventory, Workshop, Character, Settings, Complete }
#[derive(Component, Clone, Copy)] enum UiAction {
    Start,
    OpenMaps,
    OpenWorkshop,
    OpenInventory,
    OpenCharacter,
    OpenSettings,
    SelectMap(MapKind),
    BuyScanner,
    BuySuit,
    BuyBattery,
    CycleSuit,
    SetPerformance,
    SetBalanced,
    SetHigh,
    Pause,
    Resume,
    ReturnToBase,
    Interact,
}
#[derive(Component, Clone, Copy)] enum TouchAction { Forward, Backward, Left, Right, LookLeft, LookRight, Sprint }

// -----------------------------------------------------------------------------
// STARTUP AND ORIGINAL ASSETS
// -----------------------------------------------------------------------------

fn load_progress(mut save: ResMut<SaveData>, mut map: ResMut<MapConfig>) {
    let path = Path::new("saves/progress.json");
    if let Ok(contents) = fs::read_to_string(path) {
        if let Ok(loaded) = serde_json::from_str::<SaveData>(&contents) {
            *save = loaded;
        }
    }
    map.selected = save.last_map;
    map.rebuild = true;
}

fn setup_world(
    mut commands: Commands,
    asset_server: Res<AssetServer>,
    mut meshes: ResMut<Assets<Mesh>>,
    mut materials: ResMut<Assets<StandardMaterial>>,
    _map: Res<MapConfig>,
) {
    let scanner_mat = materials.add(StandardMaterial {
        base_color_texture: Some(asset_server.load("textures/scanner_basecolor.png")),
        metallic: 0.48,
        perceptual_roughness: 0.3,
        emissive: Color::srgb(0.02, 0.12, 0.14).into(),
        ..default()
    });
    let lens_mat = materials.add(StandardMaterial {
        base_color: Color::srgb(0.12, 0.86, 0.78),
        emissive: Color::srgb(0.05, 0.55, 0.48).into(),
        metallic: 0.2,
        perceptual_roughness: 0.18,
        ..default()
    });
    let scanner_mesh = meshes.add(Cuboid::new(0.16, 0.20, 0.42));
    let lens_mesh = meshes.add(Cuboid::new(0.12, 0.11, 0.035));

    // Player root -> camera -> scanner. The camera now follows player movement correctly.
    commands.spawn((Transform::from_xyz(0.0, 0.0, 16.0), PlayerRoot))
        .with_children(|player| {
            player.spawn((
                Camera3d::default(),
                Transform::from_xyz(0.0, 1.68, 0.0).looking_to(Vec3::NEG_Z, Vec3::Y),
                PlayerCamera,
            )).with_children(|camera| {
                camera.spawn((
                    Mesh3d(scanner_mesh.clone()),
                    MeshMaterial3d(scanner_mat.clone()),
                    Transform::from_xyz(0.31,-0.27,-0.58).with_rotation(Quat::from_rotation_x(-0.08)),
                ));
                camera.spawn((
                    Mesh3d(lens_mesh.clone()),
                    MeshMaterial3d(lens_mat.clone()),
                    Transform::from_xyz(0.31,-0.22,-0.80),
                ));
            });
        });

    // Three selectable explorer suits for the character screen.
    for (index, path) in [
        "models/explorer.glb",
        "models/explorer_moss.glb",
        "models/explorer_ember.glb",
    ].iter().enumerate() {
        let scene = asset_server.load(GltfAssetLabel::Scene(0).from_asset(*path));
        commands.spawn((
            SceneRoot(scene),
            Transform::from_xyz(2.7, 0.0, 0.0).with_scale(Vec3::splat(0.78)),
            Visibility::Hidden,
            PreviewAvatar(index as u8),
        ));
    }

    commands.spawn((
        DirectionalLight { illuminance: 12_000.0, shadows_enabled: true, ..default() },
        Transform::from_xyz(-8.0, 18.0, 8.0).looking_at(Vec3::ZERO, Vec3::Y),
    ));
    commands.insert_resource(AmbientLight {
        color: Color::srgb(0.52, 0.65, 0.78),
        brightness: 260.0,
    });
    commands.spawn((
        PointLight { intensity: 900.0, range: 26.0, shadows_enabled: false, color: Color::srgb(0.18, 0.78, 0.86), ..default() },
        Transform::from_xyz(-7.0, 5.5, -3.0),
    ));
    commands.spawn((
        PointLight { intensity: 520.0, range: 20.0, shadows_enabled: false, color: Color::srgb(0.95, 0.47, 0.18), ..default() },
        Transform::from_xyz(10.0, 4.0, -15.0),
    ));
}

fn setup_animation_graph(
    mut commands: Commands,
    asset_server: Res<AssetServer>,
    mut graphs: ResMut<Assets<AnimationGraph>>,
) {
    let clips = [
        asset_server.load(GltfAssetLabel::Animation(0).from_asset("models/sentinel.glb")),
        asset_server.load(GltfAssetLabel::Animation(1).from_asset("models/sentinel.glb")),
        asset_server.load(GltfAssetLabel::Animation(2).from_asset("models/sentinel.glb")),
        asset_server.load(GltfAssetLabel::Animation(3).from_asset("models/sentinel.glb")),
    ];
    let (graph, indices) = AnimationGraph::from_clips(clips);
    let handle = graphs.add(graph);
    commands.insert_resource(AnimationBank {
        graph: handle,
        idle: indices[0],
        walk: indices[1],
        scan: indices[2],
        shutdown: indices[3],
    });
}

fn bind_character_animations(
    mut commands: Commands,
    bank: Option<Res<AnimationBank>>,
    mut players: Query<(Entity, &mut AnimationPlayer), Added<AnimationPlayer>>,
) {
    let Some(bank) = bank else { return; };
    for (entity, mut player) in &mut players {
        let mut transitions = AnimationTransitions::new();
        transitions.play(&mut player, bank.idle, Duration::ZERO).repeat();
        commands.entity(entity)
            .insert(AnimationGraphHandle(bank.graph.clone()))
            .insert(CurrentClip(bank.idle))
            .insert(transitions);
    }
}

fn update_scene_animations(
    game: Res<GameState>,
    bank: Option<Res<AnimationBank>>,
    mut players: Query<(&mut AnimationPlayer,&mut AnimationTransitions,&mut CurrentClip)>,
) {
    let Some(bank)=bank else { return; };
    let desired = match game.screen {
        Screen::MissionComplete => bank.shutdown,
        Screen::Playing if game.alert > 12.0 => bank.scan,
        Screen::Playing => bank.walk,
        _ => bank.idle,
    };
    for (mut player,mut transitions,mut current) in &mut players {
        if current.0 == desired { continue; }
        let animation=transitions.play(&mut player,desired,Duration::from_millis(220));
        if desired != bank.shutdown { animation.repeat(); }
        current.0=desired;
    }
}

// -----------------------------------------------------------------------------
// WORLD BUILDING: THREE ACTUAL, REBUILDABLE MAPS
// -----------------------------------------------------------------------------

fn rebuild_world(
    mut commands: Commands,
    mut map: ResMut<MapConfig>,
    mut game: ResMut<GameState>,
    mut save: ResMut<SaveData>,
    old_level: Query<Entity, With<LevelObject>>,
    mut player: Query<&mut Transform, With<PlayerRoot>>,
    asset_server: Res<AssetServer>,
    mut meshes: ResMut<Assets<Mesh>>,
    mut materials: ResMut<Assets<StandardMaterial>>,
) {
    if !map.rebuild { return; }
    for entity in &old_level { commands.entity(entity).despawn_recursive(); }

    let ground_texture = asset_server.load(map.selected.texture());
    let ground_normal = asset_server.load(map.selected.normal_texture());
    let ground_material = materials.add(StandardMaterial {
        base_color_texture: Some(ground_texture),
        normal_map_texture: Some(ground_normal),
        base_color: Color::WHITE,
        perceptual_roughness: 0.92,
        ..default()
    });
    let wall_material = materials.add(StandardMaterial {
        base_color_texture: Some(asset_server.load("textures/concrete_basecolor.png")),
        normal_map_texture: Some(asset_server.load("textures/concrete_normal.png")),
        base_color: Color::srgb(0.78, 0.86, 0.88),
        metallic: 0.34,
        perceptual_roughness: 0.64,
        ..default()
    });
    let accent_material = materials.add(StandardMaterial {
        base_color: Color::srgb(0.08, 0.68, 0.74),
        emissive: Color::srgb(0.02, 0.34, 0.4).into(),
        metallic: 0.24,
        perceptual_roughness: 0.24,
        ..default()
    });
    let pale_material = materials.add(StandardMaterial {
        base_color: Color::srgb(0.55, 0.72, 0.78),
        metallic: 0.18,
        perceptual_roughness: 0.42,
        ..default()
    });

    let floor_tile = meshes.add(Plane3d::default().mesh().size(25.0, 25.0));
    for x in [-37.5, -12.5, 12.5, 37.5] {
        for z in [-37.5, -12.5, 12.5, 37.5] {
            commands.spawn((
                Mesh3d(floor_tile.clone()),
                MeshMaterial3d(ground_material.clone()),
                Transform::from_xyz(x, -0.08, z),
                LevelObject,
            ));
        }
    }

    // Boundary walls keep the play space readable and stop the player leaving the level.
    spawn_block(&mut commands, &mut meshes, wall_material.clone(), Vec3::new(0.0, 2.0, -43.0), Vec3::new(88.0, 4.0, 1.2));
    spawn_block(&mut commands, &mut meshes, wall_material.clone(), Vec3::new(0.0, 2.0, 43.0), Vec3::new(88.0, 4.0, 1.2));
    spawn_block(&mut commands, &mut meshes, wall_material.clone(), Vec3::new(-43.0, 2.0, 0.0), Vec3::new(1.2, 4.0, 88.0));
    spawn_block(&mut commands, &mut meshes, wall_material.clone(), Vec3::new(43.0, 2.0, 0.0), Vec3::new(1.2, 4.0, 88.0));

    match map.selected {
        MapKind::RustDunes => {
            let blocks = [
                (Vec3::new(-12.0, 1.2, -8.0), Vec3::new(8.0, 2.4, 5.0)),
                (Vec3::new(13.0, 2.0, -13.0), Vec3::new(5.5, 4.0, 7.0)),
                (Vec3::new(18.0, 1.4, 10.0), Vec3::new(8.0, 2.8, 4.0)),
                (Vec3::new(-18.0, 1.5, 12.0), Vec3::new(4.0, 3.0, 9.0)),
                (Vec3::new(0.0, 1.1, 23.0), Vec3::new(10.0, 2.2, 4.0)),
                (Vec3::new(-2.0, 1.0, -26.0), Vec3::new(9.0, 2.0, 3.5)),
                (Vec3::new(27.0, 1.5, -1.0), Vec3::new(4.0, 3.0, 9.0)),
            ];
            for (pos,size) in blocks { spawn_block(&mut commands,&mut meshes,wall_material.clone(),pos,size); }
            spawn_pillar(&mut commands,&mut meshes,accent_material.clone(),Vec3::new(-29.0,2.5,-28.0));
            spawn_pillar(&mut commands,&mut meshes,accent_material.clone(),Vec3::new(29.0,2.5,27.0));
        }
        MapKind::NeonDistrict => {
            let buildings = [
                (Vec3::new(-16.0,3.5,-12.0),Vec3::new(9.0,7.0,8.0)),
                (Vec3::new(15.0,4.5,-16.0),Vec3::new(8.0,9.0,10.0)),
                (Vec3::new(23.0,3.0,12.0),Vec3::new(7.0,6.0,11.0)),
                (Vec3::new(-22.0,4.0,15.0),Vec3::new(8.0,8.0,8.0)),
                (Vec3::new(0.0,2.0,-29.0),Vec3::new(15.0,4.0,4.0)),
                (Vec3::new(0.0,1.5,25.0),Vec3::new(18.0,3.0,4.0)),
            ];
            for (pos,size) in buildings { spawn_block(&mut commands,&mut meshes,wall_material.clone(),pos,size); }
            for x in [-30.0,-10.0,10.0,30.0] {
                spawn_pillar(&mut commands,&mut meshes,accent_material.clone(),Vec3::new(x,3.0,0.0));
            }
        }
        MapKind::FrostRelay => {
            let ice_blocks = [
                (Vec3::new(-13.0,2.0,-12.0),Vec3::new(7.0,4.0,6.0)),
                (Vec3::new(14.0,2.8,-17.0),Vec3::new(5.0,5.6,7.0)),
                (Vec3::new(20.0,1.8,12.0),Vec3::new(8.0,3.6,5.0)),
                (Vec3::new(-20.0,2.2,15.0),Vec3::new(5.0,4.4,9.0)),
                (Vec3::new(0.0,2.0,27.0),Vec3::new(12.0,4.0,4.0)),
                (Vec3::new(-2.0,1.5,-29.0),Vec3::new(10.0,3.0,4.0)),
            ];
            for (pos,size) in ice_blocks { spawn_block(&mut commands,&mut meshes,pale_material.clone(),pos,size); }
            for pos in [Vec3::new(-31.0,3.0,-26.0),Vec3::new(30.0,3.0,25.0),Vec3::new(30.0,3.0,-25.0)] {
                spawn_pillar(&mut commands,&mut meshes,accent_material.clone(),pos);
            }
        }
    }

    // Three relay beacons and four collectible data fragments are unique to each map.
    let beacon_positions = [Vec3::new(-27.0,1.75,-28.0),Vec3::new(26.0,1.75,-26.0),Vec3::new(0.0,1.75,31.0)];
    let beacon_base_mesh = meshes.add(Cuboid::new(1.8, 0.22, 1.8));
    let beacon_stem_mesh = meshes.add(Cuboid::new(0.28, 1.2, 0.28));
    let beacon_core_mesh = meshes.add(Sphere::new(0.68).mesh().uv(18,12));
    for (i,pos) in beacon_positions.iter().enumerate() {
        commands.spawn((Mesh3d(beacon_base_mesh.clone()), MeshMaterial3d(wall_material.clone()), Transform::from_xyz(pos.x,0.10,pos.z), LevelObject));
        commands.spawn((Mesh3d(beacon_stem_mesh.clone()), MeshMaterial3d(accent_material.clone()), Transform::from_xyz(pos.x,0.82,pos.z), LevelObject));
        commands.spawn((
            Mesh3d(beacon_core_mesh.clone()),
            MeshMaterial3d(accent_material.clone()),
            Transform::from_translation(*pos),
            Beacon { index: i as u8, activated: false },
            LevelObject,
        ));
    }
    for pos in [Vec3::new(-8.0,0.65,2.0),Vec3::new(8.0,0.65,-5.0),Vec3::new(23.0,0.65,28.0),Vec3::new(-24.0,0.65,4.0)] {
        commands.spawn((
            Mesh3d(meshes.add(Sphere::new(0.34).mesh().uv(12,8))),
            MeshMaterial3d(pale_material.clone()),
            Transform::from_translation(pos),
            DataFragment,
            LevelObject,
        ));
    }

    // Three distinct sentinel types use separate skinned GLB models.
    spawn_sentinel(&mut commands,&asset_server,"models/sentinel.glb",Vec3::new(-9.0,0.0,-18.0),2.15,13.0,0.0);
    spawn_sentinel(&mut commands,&asset_server,"models/sentinel_ice.glb",Vec3::new(18.0,0.0,0.0),1.25,19.0,1.7);
    spawn_sentinel(&mut commands,&asset_server,"models/sentinel_heavy.glb",Vec3::new(-25.0,0.0,20.0),0.92,8.5,3.3);

    if let Ok(mut player_transform) = player.get_single_mut() {
        player_transform.translation = Vec3::new(0.0,0.0,16.0);
        player_transform.rotation = Quat::IDENTITY;
    }
    map.rebuild = false;
    save.last_map = map.selected;
    game.beacons_found = 0;
    game.fragments_found = 0;
    game.mission_stage = 0;
    game.charge = MAX_CHARGE + (save.battery_level.saturating_sub(1) as f32 * 12.0);
    game.alert = 0.0;
    game.message = format!("{} // {}", map.selected.title(), map.selected.mission());
}

fn spawn_block(
    commands: &mut Commands,
    meshes: &mut Assets<Mesh>,
    material: Handle<StandardMaterial>,
    position: Vec3,
    size: Vec3,
) {
    commands.spawn((
        Mesh3d(meshes.add(Cuboid::new(size.x,size.y,size.z))),
        MeshMaterial3d(material),
        Transform::from_translation(position),
        MapBlocker { half: Vec2::new(size.x*0.5+0.55,size.z*0.5+0.55) },
        LevelObject,
    ));
}

fn spawn_pillar(commands: &mut Commands, meshes: &mut Assets<Mesh>, material: Handle<StandardMaterial>, position: Vec3) {
    commands.spawn((
        Mesh3d(meshes.add(Cuboid::new(0.7,5.0,0.7))),
        MeshMaterial3d(material.clone()),
        Transform::from_translation(position),
        LevelObject,
    ));
    commands.spawn((
        Mesh3d(meshes.add(Sphere::new(0.48).mesh().uv(14,10))),
        MeshMaterial3d(material),
        Transform::from_translation(position+Vec3::Y*2.7),
        LevelObject,
    ));
}

fn spawn_sentinel(
    commands: &mut Commands,
    asset_server: &AssetServer,
    model: &str,
    position: Vec3,
    speed: f32,
    detect_radius: f32,
    phase: f32,
) {
    let scene = asset_server.load(GltfAssetLabel::Scene(0).from_asset(model));
    commands.spawn((
        Transform::from_translation(position),
        Sentinel { speed, detect_radius, patrol_center: position, phase },
        LevelObject,
    )).with_children(|parent| {
        parent.spawn((SceneRoot(scene),Transform::from_scale(Vec3::splat(if speed < 1.0 { 1.18 } else if speed > 2.0 { 0.78 } else { 0.92 }))));
    });
}

// -----------------------------------------------------------------------------
// UI: MENU, MAP SELECTION, WORKSHOP, INVENTORY, SUIT EDITOR AND TOUCH CONTROLS
// -----------------------------------------------------------------------------

macro_rules! ui_button {
    ($parent:expr, $label:expr, $action:expr) => {{
        $parent.spawn((
            Button,
            Node {
                width: Val::Px(250.0), height: Val::Px(48.0),
                margin: UiRect::all(Val::Px(5.0)),
                border: UiRect::all(Val::Px(1.0)),
                justify_content: JustifyContent::Center,
                align_items: AlignItems::Center,
                ..default()
            },
            BackgroundColor(Color::srgba(0.035,0.10,0.15,0.96)),
            BorderColor(Color::srgb(0.12,0.63,0.69)),
            BorderRadius::all(Val::Px(7.0)),
            $action,
        )).with_child((
            Text::new($label),
            TextFont { font_size: 17.0, ..default() },
            TextColor(Color::srgb(0.86,0.96,0.98)),
        ));
    }};
}

macro_rules! touch_button {
    ($parent:expr, $label:expr, $action:expr, $width:expr) => {{
        $parent.spawn((
            Button,
            Node {
                width: Val::Px($width), height: Val::Px(46.0),
                margin: UiRect::all(Val::Px(4.0)),
                justify_content: JustifyContent::Center,
                align_items: AlignItems::Center,
                ..default()
            },
            BackgroundColor(Color::srgba(0.02,0.12,0.17,0.72)),
            BorderColor(Color::srgb(0.20,0.68,0.72)),
            BorderRadius::all(Val::Px(10.0)),
            $action,
        )).with_child((Text::new($label),TextFont{font_size:20.0,..default()},TextColor(Color::WHITE)));
    }};
}

fn setup_ui(mut commands: Commands) {
    commands.spawn(Camera2d);
    commands.spawn((
        Node {
            width: Val::Percent(100.0), height: Val::Percent(100.0),
            position_type: PositionType::Absolute,
            left: Val::Px(0.0), top: Val::Px(0.0),
            ..default()
        },
        UiRoot,
    )).with_children(|root| {
        // MAIN MENU
        root.spawn((page_node(0.76),BackgroundColor(page_background(0.76)),UiPage(Screen::MainMenu))).with_children(|page| {
            page.spawn((Text::new(GAME_TITLE),TextFont{font_size:48.0,..default()},TextColor(Color::srgb(0.45,0.94,0.90))));
            page.spawn((Text::new("FIELD ARCHIVE  //  EXPLORATION PROTOCOL"),TextFont{font_size:15.0,..default()},TextColor(Color::srgb(0.61,0.76,0.81))));
            page.spawn((Text::new("Three regions. One broken relay network. Rebuild the signal."),TextFont{font_size:17.0,..default()},TextColor(Color::srgb(0.80,0.88,0.91))));
            page.spawn((DynamicLabel(LabelKind::MainStats),Text::new("Loading saved expedition…"),TextFont{font_size:15.0,..default()},TextColor(Color::srgb(0.34,0.82,0.78))));
            ui_button!(page,"START EXPEDITION",UiAction::Start);
            ui_button!(page,"SELECT LOCATION",UiAction::OpenMaps);
            ui_button!(page,"FIELD WORKSHOP",UiAction::OpenWorkshop);
            ui_button!(page,"INVENTORY",UiAction::OpenInventory);
            ui_button!(page,"SUIT CONFIGURATION",UiAction::OpenCharacter);
            ui_button!(page,"SETTINGS / PERFORMANCE",UiAction::OpenSettings);
        });

        // MAP SELECT
        root.spawn((page_node(0.91),BackgroundColor(page_background(0.91)),UiPage(Screen::MapSelect))).with_children(|page| {
            heading(page,"SELECT LOCATION","Three distinct regions. Different layouts, surface materials and patrol routes.");
            ui_button!(page,"01  RUST DUNES",UiAction::SelectMap(MapKind::RustDunes));
            ui_button!(page,"02  NEON DISTRICT",UiAction::SelectMap(MapKind::NeonDistrict));
            ui_button!(page,"03  FROST RELAY",UiAction::SelectMap(MapKind::FrostRelay));
            ui_button!(page,"BACK TO BASE",UiAction::ReturnToBase);
        });

        // WORKSHOP - utility upgrades only.
        root.spawn((page_node(0.91),BackgroundColor(page_background(0.91)),UiPage(Screen::Workshop))).with_children(|page| {
            heading(page,"FIELD WORKSHOP","Spend recovered scrap on exploration equipment.");
            page.spawn((DynamicLabel(LabelKind::Workshop),Text::new("Scrap: --"),TextFont{font_size:16.0,..default()},TextColor(Color::srgb(0.32,0.85,0.78))));
            ui_button!(page,"SCANNER AMPLIFIER  //  60 SCRAP",UiAction::BuyScanner);
            ui_button!(page,"SUIT LINING  //  80 SCRAP",UiAction::BuySuit);
            ui_button!(page,"BATTERY CELL  //  40 SCRAP",UiAction::BuyBattery);
            ui_button!(page,"BACK TO BASE",UiAction::ReturnToBase);
        });

        // INVENTORY
        root.spawn((page_node(0.91),BackgroundColor(page_background(0.91)),UiPage(Screen::Inventory))).with_children(|page| {
            heading(page,"INVENTORY","Recovered resources and installed equipment.");
            page.spawn((DynamicLabel(LabelKind::Inventory),Text::new("Loading inventory…"),TextFont{font_size:17.0,..default()},TextColor(Color::srgb(0.83,0.91,0.93))));
            ui_button!(page,"BACK TO BASE",UiAction::ReturnToBase);
        });

        // CHARACTER / SUIT EDITOR
        root.spawn((page_node(0.78),BackgroundColor(page_background(0.78)),UiPage(Screen::Character))).with_children(|page| {
            heading(page,"SUIT CONFIGURATION","Choose the explorer suit colourway.");
            page.spawn((DynamicLabel(LabelKind::Character),Text::new("Suit: Polar Blue"),TextFont{font_size:18.0,..default()},TextColor(Color::srgb(0.72,0.93,0.96))));
            ui_button!(page,"CYCLE SUIT STYLE",UiAction::CycleSuit);
            ui_button!(page,"BACK TO BASE",UiAction::ReturnToBase);
        });

        // SETTINGS
        root.spawn((page_node(0.91),BackgroundColor(page_background(0.91)),UiPage(Screen::Settings))).with_children(|page| {
            heading(page,"PERFORMANCE PROFILE","Balanced is the default. Lower shadows on slower devices.");
            page.spawn((DynamicLabel(LabelKind::Settings),Text::new("Profile: BALANCED"),TextFont{font_size:17.0,..default()},TextColor(Color::srgb(0.76,0.9,0.93))));
            ui_button!(page,"PERFORMANCE",UiAction::SetPerformance);
            ui_button!(page,"BALANCED",UiAction::SetBalanced);
            ui_button!(page,"HIGH QUALITY",UiAction::SetHigh);
            ui_button!(page,"BACK TO BASE",UiAction::ReturnToBase);
        });

        // PAUSE
        root.spawn((page_node(0.86),BackgroundColor(page_background(0.86)),UiPage(Screen::Pause))).with_children(|page| {
            heading(page,"EXPEDITION PAUSED","Expedition data is stored locally on this device.");
            ui_button!(page,"RESUME",UiAction::Resume);
            ui_button!(page,"RETURN TO BASE",UiAction::ReturnToBase);
        });

        // MISSION COMPLETE
        root.spawn((page_node(0.86),BackgroundColor(page_background(0.86)),UiPage(Screen::MissionComplete))).with_children(|page| {
            heading(page,"RELAY RESTORED","Mission complete. Data fragments recovered.");
            page.spawn((DynamicLabel(LabelKind::Complete),Text::new("Results"),TextFont{font_size:17.0,..default()},TextColor(Color::srgb(0.71,0.92,0.88))));
            ui_button!(page,"RETURN TO BASE",UiAction::ReturnToBase);
        });

        // IN-GAME HUD AND TOUCH CONTROLS
        root.spawn((page_node(0.0),BackgroundColor(page_background(0.0)),UiPage(Screen::Playing))).with_children(|page| {
            page.spawn((
                Node { width:Val::Percent(100.0), justify_content:JustifyContent::SpaceBetween, flex_direction:FlexDirection::Row, align_items:AlignItems::FlexStart, ..default() },
            )).with_children(|top| {
                top.spawn((DynamicLabel(LabelKind::Hud),Text::new("CHARGE 100 | SCRAP 80"),TextFont{font_size:17.0,..default()},TextColor(Color::srgb(0.82,0.95,0.96))));
                top.spawn((DynamicLabel(LabelKind::Performance),Text::new("FPS --"),TextFont{font_size:13.0,..default()},TextColor(Color::srgb(0.40,0.83,0.76))));
                top.spawn((
                    Button,
                    Node { width: Val::Px(76.0), height: Val::Px(40.0), margin: UiRect::all(Val::Px(4.0)), justify_content: JustifyContent::Center, align_items: AlignItems::Center, ..default() },
                    BackgroundColor(Color::srgba(0.035,0.10,0.15,0.96)),
                    BorderColor(Color::srgb(0.12,0.63,0.69)),
                    BorderRadius::all(Val::Px(7.0)),
                    UiAction::Pause,
                )).with_child((Text::new("PAUSE"), TextFont { font_size: 14.0, ..default() }, TextColor(Color::WHITE)));
            });
            page.spawn((DynamicLabel(LabelKind::Quest),Text::new("OBJECTIVE: Activate the relay beacons"),TextFont{font_size:16.0,..default()},TextColor(Color::srgb(0.94,0.78,0.40))));
            page.spawn((DynamicLabel(LabelKind::Message),Text::new("Find the signal."),TextFont{font_size:14.0,..default()},TextColor(Color::srgb(0.56,0.82,0.84))));
            page.spawn((
                Node { position_type: PositionType::Absolute, left: Val::Percent(50.0), top: Val::Percent(50.0), width: Val::Px(28.0), height: Val::Px(28.0), margin: UiRect::left(Val::Px(-14.0)), justify_content: JustifyContent::Center, align_items: AlignItems::Center, ..default() },
            )).with_child((Text::new("◎"),TextFont{font_size:24.0,..default()},TextColor(Color::srgb(0.44,0.95,0.88))));
            page.spawn((
                Node { width:Val::Percent(100.0), flex_direction:FlexDirection::Row, justify_content:JustifyContent::SpaceBetween, align_items:AlignItems::FlexEnd, flex_grow:1.0, ..default() },
            )).with_children(|controls| {
                controls.spawn((Node{flex_direction:FlexDirection::Column,align_items:AlignItems::Center,justify_content:JustifyContent::Center,..default()})).with_children(|dpad| {
                    touch_button!(dpad,"▲",TouchAction::Forward,40.0);
                    dpad.spawn((Node{flex_direction:FlexDirection::Row,..default()})).with_children(|row| {
                        touch_button!(row,"◀",TouchAction::Left,40.0);
                        touch_button!(row,"▼",TouchAction::Backward,40.0);
                        touch_button!(row,"▶",TouchAction::Right,40.0);
                    });
                    touch_button!(dpad,"SPRINT",TouchAction::Sprint,92.0);
                });
                controls.spawn((Node{flex_direction:FlexDirection::Column,align_items:AlignItems::Center,justify_content:JustifyContent::Center,..default()})).with_children(|look| {
                    touch_button!(look,"LOOK ◀",TouchAction::LookLeft,48.0);
                    touch_button!(look,"SCAN",UiAction::Interact,60.0);
                    touch_button!(look,"LOOK ▶",TouchAction::LookRight,48.0);
                });
            });
        });
    });
}

fn page_node(_background_alpha: f32) -> Node {
    Node {
        width: Val::Percent(100.0), height: Val::Percent(100.0),
        position_type: PositionType::Absolute,
        left: Val::Px(0.0), top: Val::Px(0.0),
        flex_direction: FlexDirection::Column,
        justify_content: JustifyContent::Center,
        align_items: AlignItems::Center,
        padding: UiRect::all(Val::Px(14.0)),
        row_gap: Val::Px(3.0),
        ..default()
    }
}

fn page_background(alpha: f32) -> Color { Color::srgba(0.008,0.022,0.038,alpha) }

fn heading(parent: &mut ChildBuilder, title: &str, subtitle: &str) {
    parent.spawn((Text::new(title),TextFont{font_size:36.0,..default()},TextColor(Color::srgb(0.46,0.94,0.90))));
    parent.spawn((Text::new(subtitle),TextFont{font_size:15.0,..default()},TextColor(Color::srgb(0.62,0.75,0.80))));
}

fn handle_keyboard_actions(
    keys: Res<ButtonInput<KeyCode>>,
    mut game: ResMut<GameState>,
    mut map: ResMut<MapConfig>,
    mut request: ResMut<InteractionRequest>,
) {
    if keys.just_pressed(KeyCode::Escape) {
        game.screen = match game.screen {
            Screen::Playing => Screen::Pause,
            Screen::Pause => Screen::Playing,
            other => other,
        };
    }
    if keys.just_pressed(KeyCode::Enter) && game.screen == Screen::MainMenu {
        game.screen = Screen::Playing;
        map.rebuild = true;
        game.message = "Find the three relay beacons. Avoid the sentinels.".into();
    }
    if keys.just_pressed(KeyCode::KeyE) && game.screen == Screen::Playing {
        request.requested = true;
    }
}

fn handle_ui_actions(
    mut query: Query<(&Interaction, &UiAction), (Changed<Interaction>, With<Button>)>,
    mut commands: Commands,
    asset_server: Res<AssetServer>,
    mut game: ResMut<GameState>,
    mut map: ResMut<MapConfig>,
    mut save: ResMut<SaveData>,
    mut request: ResMut<InteractionRequest>,
) {
    for (interaction, action) in &mut query {
        if *interaction != Interaction::Pressed { continue; }
        commands.spawn(AudioPlayer::new(asset_server.load("audio/ui_click.wav")));
        match *action {
            UiAction::Start => {
                game.screen = Screen::Playing;
                map.rebuild = true;
                game.message = "Find the three relay beacons. Avoid the sentinels.".into();
            }
            UiAction::OpenMaps => game.screen = Screen::MapSelect,
            UiAction::OpenWorkshop => game.screen = Screen::Workshop,
            UiAction::OpenInventory => game.screen = Screen::Inventory,
            UiAction::OpenCharacter => game.screen = Screen::Character,
            UiAction::OpenSettings => game.screen = Screen::Settings,
            UiAction::SelectMap(selected) => {
                map.selected = selected;
                map.rebuild = true;
                save.last_map = selected;
                game.screen = Screen::MainMenu;
            }
            UiAction::BuyScanner => {
                if save.scrap >= 60 && save.scanner_level < 4 {
                    save.scrap -= 60; save.scanner_level += 1;
                    game.message = "Scanner range improved.".into();
                } else { game.message = "Not enough scrap or scanner is already upgraded.".into(); }
            }
            UiAction::BuySuit => {
                if save.scrap >= 80 && save.suit_level < 4 {
                    save.scrap -= 80; save.suit_level += 1;
                    game.message = "Suit lining upgraded. Sentinel detection is less sensitive.".into();
                } else { game.message = "Not enough scrap or suit is fully upgraded.".into(); }
            }
            UiAction::BuyBattery => {
                if save.scrap >= 40 && save.battery_level < 4 {
                    save.scrap -= 40; save.battery_level += 1;
                    game.charge += 12.0;
                    game.message = "Battery capacity upgraded.".into();
                } else { game.message = "Not enough scrap or battery is fully upgraded.".into(); }
            }
            UiAction::CycleSuit => {
                save.suit_choice = (save.suit_choice + 1) % 3;
            }
            UiAction::SetPerformance => game.quality = QualityPreset::Performance,
            UiAction::SetBalanced => game.quality = QualityPreset::Balanced,
            UiAction::SetHigh => game.quality = QualityPreset::High,
            UiAction::Pause => game.screen = Screen::Pause,
            UiAction::Resume => game.screen = Screen::Playing,
            UiAction::ReturnToBase => game.screen = Screen::MainMenu,
            UiAction::Interact => request.requested = true,
        }
    }
}

fn style_ui_buttons(
    mut query: Query<(&Interaction, &mut BackgroundColor, &mut BorderColor), (Changed<Interaction>, With<Button>)>,
) {
    for (interaction, mut background, mut border) in &mut query {
        let (fill, edge) = match *interaction {
            Interaction::Pressed => (Color::srgba(0.06, 0.32, 0.34, 0.98), Color::srgb(0.42, 0.98, 0.88)),
            Interaction::Hovered => (Color::srgba(0.04, 0.20, 0.24, 0.98), Color::srgb(0.24, 0.82, 0.80)),
            Interaction::None => (Color::srgba(0.035, 0.10, 0.15, 0.96), Color::srgb(0.12, 0.63, 0.69)),
        };
        *background = BackgroundColor(fill);
        *border = BorderColor(edge);
    }
}

fn collect_touch_controls(
    mut controls: ResMut<TouchControls>,
    query: Query<(&Interaction, &TouchAction), With<Button>>,
) {
    *controls = TouchControls::default();
    for (interaction, action) in &query {
        if *interaction != Interaction::Pressed { continue; }
        match *action {
            TouchAction::Forward => controls.forward = true,
            TouchAction::Backward => controls.backward = true,
            TouchAction::Left => controls.left = true,
            TouchAction::Right => controls.right = true,
            TouchAction::LookLeft => controls.look_left = true,
            TouchAction::LookRight => controls.look_right = true,
            TouchAction::Sprint => controls.sprint = true,
        }
    }
}

fn sync_ui_pages(
    game: Res<GameState>,
    mut pages: Query<(&UiPage, &mut Node)>,
) {
    for (page, mut node) in &mut pages {
        node.display = if page.0 == game.screen { Display::Flex } else { Display::None };
    }
}

fn update_ui_text(
    game: Res<GameState>,
    map: Res<MapConfig>,
    save: Res<SaveData>,
    perf: Res<PerformanceMonitor>,
    mut labels: Query<(&mut Text, &DynamicLabel)>,
) {
    for (mut text, label) in &mut labels {
        let value = match label.0 {
            LabelKind::MainStats => format!("{}   //   SCRAP {}   //   MISSIONS {}", map.selected.title(), save.scrap, save.completed_missions),
            LabelKind::Hud => format!("CHARGE {:.0}%   |   SCRAP {}   |   SUIT MK.{}", game.charge, save.scrap, save.suit_level),
            LabelKind::Quest => {
                if game.mission_stage == 0 {
                    format!("OBJECTIVE: Activate relay beacons  {}/{}", game.beacons_found, BEACONS_PER_MISSION)
                } else {
                    format!("OBJECTIVE: Recover data fragments  {}/{}", game.fragments_found, FRAGMENTS_PER_MISSION)
                }
            }
            LabelKind::Message => game.message.clone(),
            LabelKind::Performance => format!("{:.0} FPS  //  {:.1} ms  //  {} entities",perf.fps,perf.frame_ms,perf.entity_count),
            LabelKind::Inventory => format!(
                "SCRAP: {}\nDATA FRAGMENTS: {}\nTOTAL BEACONS: {}\n\nSCANNER AMPLIFIER: MK.{}\nSUIT LINING: MK.{}\nBATTERY PACK: MK.{}\n\nCURRENT LOCATION: {}",
                save.scrap,save.data_fragments,save.total_beacons,save.scanner_level,save.suit_level,save.battery_level,map.selected.title()),
            LabelKind::Workshop => format!("SCRAP AVAILABLE: {}\nSCANNER MK.{} / SUIT MK.{} / BATTERY MK.{}\n\n{}",save.scrap,save.scanner_level,save.suit_level,save.battery_level,game.message),
            LabelKind::Character => format!("SUIT STYLE: {}\nCOLOURWAY {}/3",suit_name(save.suit_choice),save.suit_choice+1),
            LabelKind::Settings => format!("PROFILE: {}\nLIVE: {:.0} FPS // {:.1} ms FRAME TIME\nRENDERED ENTITIES: {}\nCPU/GPU TEMPERATURE: NOT AVAILABLE IN THIS BUILD",quality_name(game.quality),perf.fps,perf.frame_ms,perf.entity_count),
            LabelKind::Complete => format!("LOCATION: {}\nBEACONS: {}\nFRAGMENTS: {}\nSCRAP: {}",map.selected.title(),game.beacons_found,game.fragments_found,save.scrap),
        };
        **text = value;
    }
}

fn suit_name(choice: u8) -> &'static str {
    match choice % 3 { 0 => "POLAR BLUE",1 => "MOSS FIELD",_ => "EMBER RESCUE" }
}
fn quality_name(quality: QualityPreset) -> &'static str {
    match quality { QualityPreset::Performance => "PERFORMANCE",QualityPreset::Balanced => "BALANCED",QualityPreset::High => "HIGH QUALITY" }
}

fn update_preview_visibility(
    game: Res<GameState>,
    save: Res<SaveData>,
    mut previews: Query<(&PreviewAvatar,&mut Visibility)>,
) {
    for (preview, mut visibility) in &mut previews {
        let active = preview.0 == save.suit_choice;
        *visibility = if active && matches!(game.screen,Screen::MainMenu|Screen::Character) { Visibility::Visible } else { Visibility::Hidden };
    }
}

// -----------------------------------------------------------------------------
// PLAYER, INTERACTION, PICKUPS AND NON-COMBAT SENTINEL AI
// -----------------------------------------------------------------------------

fn player_movement(
    time: Res<Time>,
    keys: Res<ButtonInput<KeyCode>>,
    controls: Res<TouchControls>,
    game: Res<GameState>,
    mut player: Query<&mut Transform,With<PlayerRoot>>,
    blockers: Query<(&Transform,&MapBlocker)>,
) {
    if game.screen != Screen::Playing { return; }
    let Ok(mut transform) = player.get_single_mut() else { return; };
    let mut direction = Vec3::ZERO;
    let forward = transform.rotation * Vec3::NEG_Z;
    let right = transform.rotation * Vec3::X;
    if keys.pressed(KeyCode::KeyW) || controls.forward { direction += forward; }
    if keys.pressed(KeyCode::KeyS) || controls.backward { direction -= forward; }
    if keys.pressed(KeyCode::KeyA) || controls.left { direction -= right; }
    if keys.pressed(KeyCode::KeyD) || controls.right { direction += right; }
    if direction.length_squared() > 0.0 {
        direction.y = 0.0;
        direction = direction.normalize();
        let sprint = keys.pressed(KeyCode::ShiftLeft) || controls.sprint;
        let speed = PLAYER_SPEED * if sprint { SPRINT_MULTIPLIER } else { 1.0 };
        let next = transform.translation + direction * speed * time.delta_secs();
        let blocked = blockers.iter().any(|(block_t,block)| {
            (next.x-block_t.translation.x).abs() < block.half.x && (next.z-block_t.translation.z).abs() < block.half.y
        });
        if !blocked {
            transform.translation.x = next.x.clamp(-39.0,39.0);
            transform.translation.z = next.z.clamp(-39.0,39.0);
        }
    }
}

fn camera_look(
    time: Res<Time>,
    mut mouse_motion: EventReader<MouseMotion>,
    mouse: Res<ButtonInput<MouseButton>>,
    controls: Res<TouchControls>,
    game: Res<GameState>,
    mut player: Query<&mut Transform,With<PlayerRoot>>,
    mut camera: Query<&mut Transform,With<PlayerCamera>>,
) {
    if game.screen != Screen::Playing { return; }
    let yaw_button = (controls.look_right as i8 - controls.look_left as i8) as f32;
    if let Ok(mut root) = player.get_single_mut() {
        root.rotate_y(yaw_button * 1.7 * time.delta_secs());
        if mouse.pressed(MouseButton::Right) {
            let delta = mouse_motion.read().fold(Vec2::ZERO,|acc,event|acc+event.delta);
            root.rotate_y(-delta.x*0.0024);
            if let Ok(mut cam) = camera.get_single_mut() {
                let (yaw,pitch,roll)=cam.rotation.to_euler(EulerRot::YXZ);
                cam.rotation=Quat::from_euler(EulerRot::YXZ,yaw,(pitch-delta.y*0.0024).clamp(-1.15,1.15),roll);
            }
        }
    }
}

fn handle_interaction(
    mut request: ResMut<InteractionRequest>,
    mut game: ResMut<GameState>,
    mut save: ResMut<SaveData>,
    player: Query<&Transform,With<PlayerRoot>>,
    mut beacons: Query<(&Transform,&mut Beacon)>,
    asset_server: Res<AssetServer>,
    mut commands: Commands,
) {
    if !request.requested || game.screen != Screen::Playing { request.requested = false; return; }
    request.requested = false;
    let Ok(player_t) = player.get_single() else { return; };
    let mut nearest: Option<(f32,u8)> = None;
    for (transform,beacon) in &mut beacons {
        if beacon.activated { continue; }
        let d=player_t.translation.distance(transform.translation);
        let scan_range=4.0+(save.scanner_level.saturating_sub(1) as f32*0.9);
        if d < scan_range && nearest.map(|(distance,_)|d<distance).unwrap_or(true) { nearest=Some((d,beacon.index)); }
    }
    if let Some((_,index))=nearest {
        for (_,mut beacon) in &mut beacons {
            if beacon.index==index { beacon.activated=true; }
        }
        game.beacons_found=game.beacons_found.saturating_add(1);
        save.total_beacons=save.total_beacons.saturating_add(1);
        save.scrap=save.scrap.saturating_add(15);
        game.message=format!("RELAY BEACON {} RESTORED  //  +15 SCRAP",index+1);
        commands.spawn(AudioPlayer::new(asset_server.load("audio/beacon.wav")));
    } else {
        game.message="Move closer to an inactive relay beacon.".into();
    }
}

fn collect_pickups(
    mut commands: Commands,
    asset_server: Res<AssetServer>,
    player: Query<&Transform,With<PlayerRoot>>,
    pickups: Query<(Entity,&Transform),With<DataFragment>>,
    mut save: ResMut<SaveData>,
    mut game: ResMut<GameState>,
) {
    if game.screen != Screen::Playing || game.mission_stage != 1 { return; }
    let Ok(player_t)=player.get_single() else { return; };
    for (entity,transform) in &pickups {
        if player_t.translation.distance(transform.translation)<1.9 {
            commands.entity(entity).despawn();
            game.fragments_found=game.fragments_found.saturating_add(1);
            save.data_fragments=save.data_fragments.saturating_add(1);
            save.scrap=save.scrap.saturating_add(8);
            game.message="DATA FRAGMENT RECOVERED  //  +8 SCRAP".into();
            commands.spawn(AudioPlayer::new(asset_server.load("audio/collect.wav")));
        }
    }
}

fn sentinel_ai(
    time: Res<Time>,
    asset_server: Res<AssetServer>,
    mut commands: Commands,
    save: Res<SaveData>,
    mut game: ResMut<GameState>,
    mut player: Query<&mut Transform,With<PlayerRoot>>,
    mut sentinels: Query<(&mut Transform,&mut Sentinel)>,
) {
    if game.screen != Screen::Playing { return; }
    let Ok(mut player_t)=player.get_single_mut() else { return; };
    let player_pos=player_t.translation;
    for (mut transform,mut sentinel) in &mut sentinels {
        sentinel.phase += time.delta_secs();
        let to_player=player_pos-transform.translation;
        let distance=to_player.length();
        let detection_factor=1.0-(save.suit_level.saturating_sub(1) as f32*0.08);
        let effective_radius=sentinel.detect_radius*detection_factor.max(0.65);
        let pursuing=distance<effective_radius;
        let target=if pursuing {
            game.alert=(game.alert+time.delta_secs()*6.5).min(100.0);
            player_pos
        } else {
            sentinel.patrol_center+Vec3::new((sentinel.phase*0.58).sin()*5.0,0.0,(sentinel.phase*0.42).cos()*4.0)
        };
        let delta=target-transform.translation;
        let flat=Vec3::new(delta.x,0.0,delta.z);
        if flat.length_squared()>0.08 {
            let speed=sentinel.speed*if pursuing {1.0} else {0.42};
            transform.translation+=flat.normalize()*speed*time.delta_secs();
            transform.look_at(Vec3::new(target.x,transform.translation.y,target.z),Vec3::Y);
        }
        if pursuing && distance<1.8 {
            player_t.translation=Vec3::new(0.0,0.0,16.0);
            game.charge=(game.charge-10.0).max(0.0);
            game.alert=0.0;
            game.message="SENTINEL TAGGED YOUR SIGNAL // RETURNED TO CHECKPOINT".into();
            commands.spawn(AudioPlayer::new(asset_server.load("audio/alert.wav")));
        }
    }
    if game.alert>0.0 { game.alert=(game.alert-time.delta_secs()*3.0).max(0.0); }
}

fn update_mission(
    mut game: ResMut<GameState>,
    mut save: ResMut<SaveData>,
) {
    if game.screen != Screen::Playing { return; }
    if game.mission_stage==0 && game.beacons_found>=BEACONS_PER_MISSION {
        game.mission_stage=1;
        game.message="RELAY ONLINE // Recover the four data fragments.".into();
    }
    if game.mission_stage==1 && game.fragments_found>=FRAGMENTS_PER_MISSION {
        game.screen=Screen::MissionComplete;
        save.completed_missions=save.completed_missions.saturating_add(1);
        game.message="MISSION COMPLETE // Signal archive recovered.".into();
    }
}

// -----------------------------------------------------------------------------
// PERFORMANCE PROFILE AND LOCAL SAVE
// -----------------------------------------------------------------------------

fn update_performance(
    time: Res<Time>,
    game: Res<GameState>,
    mut perf: ResMut<PerformanceMonitor>,
    entities: Query<Entity>,
    mut lights: Query<&mut DirectionalLight>,
    mut point_lights: Query<&mut PointLight>,
) {
    let dt=time.delta_secs().max(0.0001);
    perf.fps=perf.fps*0.88+(1.0/dt)*0.12;
    perf.frame_ms=1000.0/perf.fps.max(1.0);
    if perf.update_timer.tick(time.delta()).just_finished() {
        perf.entity_count=entities.iter().count();
    }
    let shadows=matches!(game.quality,QualityPreset::Balanced|QualityPreset::High);
    for mut light in &mut lights { light.shadows_enabled=shadows; light.illuminance=if game.quality==QualityPreset::High { 15_000.0 } else { 12_000.0 }; }
    for mut light in &mut point_lights { light.shadows_enabled=game.quality==QualityPreset::High; }
}

fn save_progress(save: Res<SaveData>, mut last_save: Local<Option<SaveData>>) {
    if !save.is_changed() { return; }
    if last_save.as_ref()==Some(&*save) { return; }
    if fs::create_dir_all("saves").is_ok() {
        if let Ok(json)=serde_json::to_string_pretty(&*save) {
            let _=fs::write("saves/progress.json",json);
        }
    }
    *last_save=Some((*save).clone());
}
